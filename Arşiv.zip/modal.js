var myDuyuruModal;

class DuyuruModal {
    constructor(bind) {
        this.index = 0;
        this.bind = bind;
        this.dondurulecek = [];
    }
    
    sonraki() {
        this.index++;
        this.render();
    }

    onceki () {
        this.index--;
        this.render();
    }

    dondure_ekle(par) {
        let index = this.dondurulecek.findIndex(x => x == par);
        if(index == -1) {
            this.dondurulecek.push(par);
        } else {
            this.dondurulecek.splice(index, 1);
        }
        console.log(this.dondurulecek);
        
    }

    kapat() {
        fetch(this.closeUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({
                kapatilan: this.dondurulecek
            })
        }).then(r => r.json)
        .then(res => {
            
        })
    }

    createTemplate(data) {        
        let temp = `
        <div id="modal" class="modal-main">
        <div class="onceki" onclick='myDuyuruModal.onceki()'`;
        temp +=  (this.index > 0) ? ` style='visibility: visible'` : `style='visibility:hidden'`;
        temp += `>
                <i class="fas fa-arrow-circle-left"></i>
            </div>`;
            temp += `
            <div class="modal">
                <div class="modal-header">
                    <span class="modal-title">${data.title}</span>
                    <i class='fas fa-close-circle'></i>    
                </div>
                <div class="modal-body">
                    ${data.content}
                </div>
                <div class="modal-footer">
                    <span><input class='gosterme' `;
                    if(this.dondurulecek.findIndex(x => x == data.uid) != -1) temp += 'checked'
                    temp += ` onchange='myDuyuruModal.dondure_ekle(${data.uid})' data_index='${this.index}' uid='${data.uid}' type='checkbox'> Bu duyuruyu bir daha gösterme!</span>
                    <button id='kapat_buton' onclick='myDuyuruModal.kapat()'> Kapat </button>
                </div>
            </div>
            <div class="sonraki" onclick='myDuyuruModal.sonraki()'`;
            temp +=  (this.index<this.data.length-1) ? ` style='visibility: visible'` : `style='visibility:hidden'`;
            temp +=`>
                <i class="fas fa-arrow-circle-right"></i>
            </div>`;
            temp += `
        </div>`;
        return temp;
    }

    static create(bind) {
        myDuyuruModal = new DuyuruModal(bind);
        return myDuyuruModal;
    }

    check(url, closeUrl) {
        this.closeUrl = closeUrl;
        fetch(url, {
            method: 'GET'
        }).then(r => r.json())
        .then(res => {
            if(res.length > 0){
                this.data = res;
                this.render();
            }
        });
    }
    
    render() {
        this.mObject = this;
        document.querySelector(this.bind).innerHTML = this.createTemplate(this.data[this.index]);
    }
}